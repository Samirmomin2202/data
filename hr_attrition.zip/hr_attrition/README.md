# HR Analytics — Employee Attrition

Portfolio project using the IBM HR Analytics dataset. It includes normalized MySQL analysis, a class-balanced prediction model, and a three-page Power BI executive dashboard specification.

## Run

```powershell
pip install -r requirements.txt
python run_pipeline.py
jupyter notebook attrition_analysis.ipynb
```

For MySQL, create a database, run `sql/schema.sql`, load the source file into `hr_staging`, then run `sql/transform.sql` and `sql/attrition_analysis.sql`.

`run_pipeline.py` trains the model, calculates each employee's flight-risk probability, and produces the final dashboard import file: `outputs/hr_dashboard_data_enhanced.csv`.

For the complete advanced report layout, theme, measures, drill-through, tooltips, and accessibility setup, see `powerbi/dashboard_build.md`. Power BI Desktop is required to save the final `.pbix` file.
