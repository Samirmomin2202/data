"""Train an imbalanced-learning-aware IBM HR attrition model.

Exports probability scores and Power BI-ready rows to ``outputs``.
Set ``HR_DATA_DIR`` to the directory that contains the IBM HR CSV when it is
not stored in the default KaggleHub cache location.
"""

import json
import os
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


ROOT = Path(__file__).resolve().parent
FEATURES = [
    "Age", "BusinessTravel", "Department", "DistanceFromHome",
    "EnvironmentSatisfaction", "Gender", "JobInvolvement", "JobLevel",
    "JobRole", "JobSatisfaction", "MaritalStatus", "MonthlyIncome",
    "NumCompaniesWorked", "OverTime", "PercentSalaryHike",
    "PerformanceRating", "StockOptionLevel", "TotalWorkingYears",
    "TrainingTimesLastYear", "WorkLifeBalance", "YearsAtCompany",
    "YearsInCurrentRole", "YearsSinceLastPromotion", "YearsWithCurrManager",
]


def source_file() -> Path:
    default_cache = Path.home() / ".cache" / "kagglehub" / "datasets" / "pavansubhasht" / "ibm-hr-analytics-attrition-dataset" / "versions" / "1"
    csv = next(Path(os.getenv("HR_DATA_DIR", default_cache)).glob("*.csv"), None)
    if csv is None:
        raise FileNotFoundError("Set HR_DATA_DIR to the folder containing the IBM HR CSV dataset.")
    return csv


def main() -> None:
    df = pd.read_csv(source_file())
    df["AttritionFlag"] = (df["Attrition"] == "Yes").astype(int)
    df["Tenure Bucket"] = pd.cut(
        df["YearsAtCompany"], [-1, 1, 3, 5, float("inf")],
        labels=["0-1yr", "1-3yr", "3-5yr", "5+yr"],
    )
    role_median = df.groupby("JobRole")["MonthlyIncome"].transform("median")
    df["FlightRisk"] = (
        (df["JobSatisfaction"] <= 2)
        & (df["YearsSinceLastPromotion"] >= 3)
        & (df["MonthlyIncome"] < role_median)
    ).map({True: "High", False: "Standard"})

    numeric = df[FEATURES].select_dtypes(include="number").columns.tolist()
    categorical = [column for column in FEATURES if column not in numeric]
    preprocessor = ColumnTransformer([
        ("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), numeric),
        ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical),
    ])
    X_train, X_test, y_train, y_test = train_test_split(
        df[FEATURES], df["AttritionFlag"], test_size=0.25,
        stratify=df["AttritionFlag"], random_state=42,
    )
    model = Pipeline([
        ("prep", preprocessor),
        ("classifier", LogisticRegression(class_weight="balanced", max_iter=2000, random_state=42)),
    ])
    model.fit(X_train, y_train)
    probability = model.predict_proba(X_test)[:, 1]
    prediction = (probability >= 0.5).astype(int)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_test, prediction, average="binary", zero_division=0,
    )
    metrics = {
        "test_employees": len(y_test), "attrition_rate": round(float(y_test.mean()), 4),
        "precision": round(float(precision), 4), "recall": round(float(recall), 4),
        "f1": round(float(f1), 4), "roc_auc": round(float(roc_auc_score(y_test, probability)), 4),
    }
    df["AttritionRiskProbability"] = model.predict_proba(df[FEATURES])[:, 1]
    df["RiskBand"] = pd.cut(
        df["AttritionRiskProbability"], [-0.01, 0.35, 0.60, 1],
        labels=["Low", "Medium", "High"],
    )
    output = ROOT / "outputs"
    output.mkdir(exist_ok=True)
    df.to_csv(output / "hr_dashboard_data.csv", index=False)
    (output / "attrition_model_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    print("Saved Power BI data to outputs/hr_dashboard_data.csv")


if __name__ == "__main__":
    main()
