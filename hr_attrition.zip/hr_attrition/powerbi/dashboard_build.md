# Advanced HR Attrition dashboard

## Setup

1. In Power BI Desktop, import `../outputs/hr_dashboard_data_enhanced.csv` and name the table `hr_dashboard_data`.
2. Set `AttritionRiskProbability` to decimal number and all income/years fields to whole number.
3. Create the measures and calculated column in `measures.dax`. Set all rate measures to percentage with one decimal place.
4. Import `HR_Attrition_Executive.json` through **View > Themes > Browse for themes**.
5. Add a report-page tooltip named `Employee Risk Tooltip`: cards for EmployeeNumber, Risk Priority Score, MonthlyIncome, JobSatisfaction, WorkLifeBalance, and YearsSinceLastPromotion.

## 1. Executive Overview

Top row: Total Employees, Attrition Count, Attrition Rate, Expected Leavers, High Flight Risk.

Middle: bar chart of Department by Attrition Rate (analytics average line); line-and-column chart of Tenure Bucket by Total Employees and Attrition Rate; decomposition tree with Attrition Count analysed by Department, JobRole, OverTime, and MaritalStatus.

Bottom: heatmap matrix of JobSatisfaction by WorkLifeBalance coloured by Attrition Rate; bar chart of Salary Quartile by Attrition Rate; key influencers visual with Attrition as the analysed field.

Slicers: Department, JobRole, Gender, OverTime, BusinessTravel. Sync them across all pages.

## 2. Risk & Retention Action Centre

Top row: High Flight Risk, High Flight Risk Rate, Expected Attrition Rate, Average Tenure.

Main visual: table sorted descending by Risk Priority Score. Include EmployeeNumber, Department, JobRole, Risk Priority, AttritionRiskProbability, MonthlyIncome, OverTime, JobSatisfaction, WorkLifeBalance, YearsSinceLastPromotion. Apply conditional formatting: red data bars to probability, amber icons to promotion delay, and a red/amber/green background to Risk Priority.

Side visuals: scatter plot (MonthlyIncome × YearsAtCompany, bubble size AttritionRiskProbability, legend RiskBand); stacked column Department by RiskBand; ribbon chart showing JobRole ranked by Attrition Rate.

Filter the action table to RiskBand = High, then drillthrough to this page from every other visual using Department and JobRole.

## 3. Workforce Drivers

Use small multiples for Department on a column chart: JobRole by Attrition Rate. Add a scatter of DistanceFromHome × MonthlyIncome with legend Attrition. Add a matrix of BusinessTravel and OverTime with Total Employees, Attrition Count, Attrition Rate, and Attrition Rate Variance. Add a what-if parameter named `Target attrition rate` (0% to 30%, increment 0.5%) and a card displaying `[Attrition Rate] - SELECTEDVALUE('Target attrition rate'[Target attrition rate])`.

## Interaction and usability

Keep KPI cards and slicers visible on each page. Use edit interactions so the risk table is filtered by charts, but the benchmark card is not. Add a reset-slicers button through a bookmark, page-navigation buttons, and accessible alt text for each chart. Use the tooltip page on bars and scatter points.
