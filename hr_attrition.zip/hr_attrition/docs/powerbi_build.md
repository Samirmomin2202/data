# Build the Power BI `.pbix`

Power BI Desktop creates the `.pbix`: import `outputs/hr_dashboard_data_enhanced.csv`, build the visuals below, then select **File → Save As → hr_attrition_dashboard.pbix**.

## Measures

Create the measures in `powerbi/measures.dax`. Format rate measures as percentages with one decimal place.

## Page design

- KPI cards: Total Employees, Attrition Count, Attrition Rate, Average Monthly Income, and High Flight Risk.
- Clustered bar: Department by Attrition Rate.
- Line and column chart: Tenure Bucket by Total Employees and Attrition Rate.
- Matrix: EmployeeNumber, Department, JobRole, MonthlyIncome, YearsSinceLastPromotion, Risk Priority, and AttritionRiskProbability.
- Slicers: Department, JobRole, Gender, OverTime, MaritalStatus, and BusinessTravel.

Use `powerbi/HR_Attrition_Executive.json` as the report theme. For the complete three-page executive report, including drill-through, tooltips, conditional formatting, and accessibility, follow `powerbi/dashboard_build.md`.
