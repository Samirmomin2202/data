# HR normalized schema

```mermaid
erDiagram
  departments ||--o{ employees : contains
  employees ||--|| compensation : has
  employees ||--|| performance : has
  employees ||--|| job_history : has
  departments { int department_id PK varchar department_name }
  employees { int employee_id PK int department_id FK int age varchar gender varchar marital_status varchar job_role tinyint attrition_flag }
  compensation { int employee_id PK decimal monthly_income int salary_hike_pct int stock_option_level }
  performance { int employee_id PK int job_satisfaction int environment_satisfaction int performance_rating int work_life_balance }
  job_history { int employee_id PK int years_at_company int years_in_current_role int years_since_last_promotion int num_companies_worked }
```

`hr_staging` is a raw landing table; it is not used for reporting. The four employee-extension tables are one-to-one with `employees`, avoiding duplicated department and compensation/performance attributes.
