CREATE DATABASE IF NOT EXISTS hr_analytics;
USE hr_analytics;

CREATE TABLE departments (
  department_id INT AUTO_INCREMENT PRIMARY KEY,
  department_name VARCHAR(80) NOT NULL UNIQUE
);
CREATE TABLE employees (
  employee_id INT PRIMARY KEY, age TINYINT NOT NULL, gender VARCHAR(20), marital_status VARCHAR(30),
  department_id INT NOT NULL, job_role VARCHAR(100), education_level TINYINT, education_field VARCHAR(80),
  business_travel VARCHAR(40), distance_from_home INT, overtime_flag TINYINT NOT NULL, attrition_flag TINYINT NOT NULL,
  CONSTRAINT fk_employee_department FOREIGN KEY (department_id) REFERENCES departments(department_id)
);
CREATE TABLE compensation (
  employee_id INT PRIMARY KEY, monthly_income DECIMAL(12,2) NOT NULL, salary_hike_pct TINYINT,
  stock_option_level TINYINT, daily_rate DECIMAL(12,2), hourly_rate DECIMAL(12,2),
  CONSTRAINT fk_comp_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
CREATE TABLE performance (
  employee_id INT PRIMARY KEY, job_satisfaction TINYINT, environment_satisfaction TINYINT,
  performance_rating TINYINT, work_life_balance TINYINT, relationship_satisfaction TINYINT, job_involvement TINYINT,
  CONSTRAINT fk_perf_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
CREATE TABLE job_history (
  employee_id INT PRIMARY KEY, total_working_years TINYINT, years_at_company TINYINT, years_in_current_role TINYINT,
  years_since_last_promotion TINYINT, years_with_curr_manager TINYINT, num_companies_worked TINYINT,
  training_times_last_year TINYINT,
  CONSTRAINT fk_history_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
CREATE INDEX idx_employees_department_attrition ON employees(department_id, attrition_flag);
CREATE INDEX idx_history_tenure ON job_history(years_at_company);
CREATE INDEX idx_comp_income ON compensation(monthly_income);

-- Raw CSV landing table. Load all source columns as text, then transform them.
CREATE TABLE hr_staging (
 Age VARCHAR(20), Attrition VARCHAR(10), BusinessTravel VARCHAR(40), DailyRate VARCHAR(20), Department VARCHAR(80),
 DistanceFromHome VARCHAR(20), Education VARCHAR(20), EducationField VARCHAR(80), EmployeeCount VARCHAR(20), EmployeeNumber VARCHAR(20),
 EnvironmentSatisfaction VARCHAR(20), Gender VARCHAR(20), HourlyRate VARCHAR(20), JobInvolvement VARCHAR(20), JobLevel VARCHAR(20),
 JobRole VARCHAR(100), JobSatisfaction VARCHAR(20), MaritalStatus VARCHAR(30), MonthlyIncome VARCHAR(20), MonthlyRate VARCHAR(20),
 NumCompaniesWorked VARCHAR(20), Over18 VARCHAR(10), OverTime VARCHAR(10), PercentSalaryHike VARCHAR(20), PerformanceRating VARCHAR(20),
 RelationshipSatisfaction VARCHAR(20), StandardHours VARCHAR(20), StockOptionLevel VARCHAR(20), TotalWorkingYears VARCHAR(20),
 TrainingTimesLastYear VARCHAR(20), WorkLifeBalance VARCHAR(20), YearsAtCompany VARCHAR(20), YearsInCurrentRole VARCHAR(20),
 YearsSinceLastPromotion VARCHAR(20), YearsWithCurrManager VARCHAR(20)
);
