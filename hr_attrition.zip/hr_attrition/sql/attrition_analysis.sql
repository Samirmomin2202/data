USE hr_analytics;
-- Overall and department attrition (explicit JOIN).
SELECT 'Overall' AS segment, ROUND(100*AVG(attrition_flag),2) AS attrition_rate_pct FROM employees
UNION ALL
SELECT d.department_name, ROUND(100*AVG(e.attrition_flag),2) FROM employees e JOIN departments d ON d.department_id=e.department_id GROUP BY d.department_name;

-- Tenure buckets.
SELECT CASE WHEN j.years_at_company <= 1 THEN '0-1yr' WHEN j.years_at_company <= 3 THEN '1-3yr' WHEN j.years_at_company <= 5 THEN '3-5yr' ELSE '5+yr' END AS tenure_bucket,
 COUNT(*) employees, ROUND(100*AVG(e.attrition_flag),2) attrition_rate_pct
FROM employees e JOIN job_history j ON j.employee_id=e.employee_id GROUP BY tenure_bucket ORDER BY FIELD(tenure_bucket,'0-1yr','1-3yr','3-5yr','5+yr');

-- Salary quartiles using MySQL 8 window functions.
WITH ranked AS (SELECT e.attrition_flag, NTILE(4) OVER(ORDER BY c.monthly_income) AS salary_quartile FROM employees e JOIN compensation c ON c.employee_id=e.employee_id)
SELECT salary_quartile, COUNT(*) employees, ROUND(100*AVG(attrition_flag),2) attrition_rate_pct FROM ranked GROUP BY salary_quartile;

-- Satisfaction and work-life balance association with attrition.
SELECT p.job_satisfaction, p.work_life_balance, COUNT(*) employees, ROUND(100*AVG(e.attrition_flag),2) attrition_rate_pct
FROM employees e JOIN performance p ON p.employee_id=e.employee_id GROUP BY p.job_satisfaction,p.work_life_balance ORDER BY attrition_rate_pct DESC;

CREATE OR REPLACE VIEW vw_flight_risk_employees AS
SELECT e.employee_id,e.job_role,d.department_name,c.monthly_income,p.job_satisfaction,p.work_life_balance,j.years_since_last_promotion,
       'Low satisfaction + stalled promotion + below-role median salary' AS risk_reason
FROM employees e JOIN departments d ON d.department_id=e.department_id JOIN compensation c ON c.employee_id=e.employee_id
JOIN performance p ON p.employee_id=e.employee_id JOIN job_history j ON j.employee_id=e.employee_id
WHERE p.job_satisfaction <= 2 AND j.years_since_last_promotion >= 3
  AND c.monthly_income < (SELECT AVG(c2.monthly_income) FROM employees e2 JOIN compensation c2 ON c2.employee_id=e2.employee_id WHERE e2.job_role=e.job_role);

DELIMITER //
CREATE PROCEDURE get_department_attrition_summary(IN p_department_id INT)
BEGIN
 SELECT d.department_name,COUNT(*) AS employees,SUM(e.attrition_flag) AS leavers,ROUND(100*AVG(e.attrition_flag),2) AS attrition_rate_pct,
        ROUND(AVG(c.monthly_income),2) AS avg_monthly_income,ROUND(AVG(j.years_at_company),2) AS avg_tenure_years
 FROM employees e JOIN departments d ON d.department_id=e.department_id JOIN compensation c ON c.employee_id=e.employee_id JOIN job_history j ON j.employee_id=e.employee_id
 WHERE e.department_id=p_department_id GROUP BY d.department_name;
END //
DELIMITER ;

SELECT * FROM vw_flight_risk_employees ORDER BY years_since_last_promotion DESC,monthly_income;
