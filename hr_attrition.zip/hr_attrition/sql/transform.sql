USE hr_analytics;
START TRANSACTION;
INSERT INTO departments(department_name) SELECT DISTINCT Department FROM hr_staging WHERE Department IS NOT NULL;
INSERT INTO employees(employee_id,age,gender,marital_status,department_id,job_role,education_level,education_field,business_travel,distance_from_home,overtime_flag,attrition_flag)
SELECT CAST(s.EmployeeNumber AS UNSIGNED),CAST(s.Age AS UNSIGNED),s.Gender,s.MaritalStatus,d.department_id,s.JobRole,CAST(s.Education AS UNSIGNED),s.EducationField,s.BusinessTravel,CAST(s.DistanceFromHome AS UNSIGNED),s.OverTime='Yes',s.Attrition='Yes'
FROM hr_staging s JOIN departments d ON d.department_name=s.Department;
INSERT INTO compensation SELECT CAST(EmployeeNumber AS UNSIGNED),CAST(MonthlyIncome AS DECIMAL(12,2)),CAST(PercentSalaryHike AS UNSIGNED),CAST(StockOptionLevel AS UNSIGNED),CAST(DailyRate AS DECIMAL(12,2)),CAST(HourlyRate AS DECIMAL(12,2)) FROM hr_staging;
INSERT INTO performance SELECT CAST(EmployeeNumber AS UNSIGNED),CAST(JobSatisfaction AS UNSIGNED),CAST(EnvironmentSatisfaction AS UNSIGNED),CAST(PerformanceRating AS UNSIGNED),CAST(WorkLifeBalance AS UNSIGNED),CAST(RelationshipSatisfaction AS UNSIGNED),CAST(JobInvolvement AS UNSIGNED) FROM hr_staging;
INSERT INTO job_history SELECT CAST(EmployeeNumber AS UNSIGNED),CAST(TotalWorkingYears AS UNSIGNED),CAST(YearsAtCompany AS UNSIGNED),CAST(YearsInCurrentRole AS UNSIGNED),CAST(YearsSinceLastPromotion AS UNSIGNED),CAST(YearsWithCurrManager AS UNSIGNED),CAST(NumCompaniesWorked AS UNSIGNED),CAST(TrainingTimesLastYear AS UNSIGNED) FROM hr_staging;
COMMIT;
