"""Prepare the Power BI HR attrition dataset with risk-priority fields.

Run from the project folder:
    python enhance_dashboard_data.py
"""

from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
INPUT_FILE = PROJECT_DIR / "outputs" / "hr_dashboard_data.csv"
OUTPUT_FILE = PROJECT_DIR / "outputs" / "hr_dashboard_data_enhanced.csv"


def priority_label(score: float) -> str:
    if score >= 0.70:
        return "1 · Urgent"
    if score >= 0.45:
        return "2 · Watch"
    return "3 · Monitor"


def main() -> None:
    df = pd.read_csv(INPUT_FILE)

    required = {
        "AttritionRiskProbability",
        "YearsSinceLastPromotion",
        "OverTime",
        "MonthlyIncome",
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(sorted(missing))}")

    # Risk score: prediction probability + promotion-delay and overtime signals.
    df["Risk Priority Score"] = (
        df["AttritionRiskProbability"].astype(float)
        + df["YearsSinceLastPromotion"].clip(upper=5).astype(float).mul(0.02)
        + df["OverTime"].eq("Yes").astype(float).mul(0.10)
    ).round(4)
    df["Risk Priority"] = df["Risk Priority Score"].map(priority_label)

    # Salary segment used in the Workforce Drivers report page.
    q1, q2, q3 = df["MonthlyIncome"].quantile([0.25, 0.50, 0.75])
    df["Salary Quartile"] = pd.cut(
        df["MonthlyIncome"],
        bins=[float("-inf"), q1, q2, q3, float("inf")],
        labels=["Q1 · Lowest", "Q2", "Q3", "Q4 · Highest"],
        include_lowest=True,
    )

    df.to_csv(OUTPUT_FILE, index=False)
    print(f"Created: {OUTPUT_FILE}")
    print(df[["Risk Priority", "Risk Priority Score", "Salary Quartile"]].head())


if __name__ == "__main__":
    main()
