"""Build the complete Power BI-ready HR attrition dataset.

Run from the project folder:
    python run_pipeline.py
"""

from attrition_model import main as build_model_data
from enhance_dashboard_data import main as add_dashboard_fields


def main() -> None:
    build_model_data()
    add_dashboard_fields()
    print("\nComplete. Import outputs/hr_dashboard_data_enhanced.csv into Power BI.")


if __name__ == "__main__":
    main()
